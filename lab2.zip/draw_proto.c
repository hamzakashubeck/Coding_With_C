/* Hamza Kashubeck */
/* Prototype for initializing graphics and drawing several objects */

#include "invaders.h"
#include <stdio.h>

/* sets up graphics with base and alien, waits for user input, then teardown */
int main()
{
	int i =0;
	if (i=sa_initialize())
	{
	    sa_clear();
	    sa_base(0.0);
	    sa_alien(3,1,7.0,12.0);
	    sa_refresh();
	    getchar();
	    sa_teardown();
	}
	return i;
}


