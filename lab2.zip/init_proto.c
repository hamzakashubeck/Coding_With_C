/* Hamza Kashubeck */
/* Prototype for initializing graphics */

#include "invaders.h"
#include <stdio.h>

/* initializes display, waits for user input, then teardown */
int main()
{
	int i=0;
	if (i=sa_initialize())
	{
	    sa_refresh();
	    getchar();
	    sa_teardown();
	}
	return i;
}


