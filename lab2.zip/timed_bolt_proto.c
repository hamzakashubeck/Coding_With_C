/* Hamza Kashubeck */
/* takes my last prototype with alien motion (motion_proto) and adds a bolt that fires once every second */

#include "invaders.h"
#include <stdio.h>

#define DT 0.03125
#define TYPE 1
#define COLOR 1

/* initializes graphics and draws an alien (in motion) and the base. A bolt is fired every second. */
int main()
{
	int i =0;

/* define the alien's coordinates and values here!! */
	double x = 7.0, y = 12.0;
	double vx = 10.0, vy = -2.0;
	
	double time = 0.0, oldTime = -1.0;
	if (i=sa_initialize())
	{
	    sa_clear();
	    sa_base(0.0);
	    sa_refresh();

	    while (y>0)
	    {
	        x = x + (vx*DT);
	        y = y + (vy*DT);
	        if ((x >= 39.0 && vx > 0.0) || (x <= -39.0 && vx < 0.0))
	        {
	            vx = vx*-1.0;
	        }
		time = time + DT;

	        sa_clear();
	        sa_base(0.0);
	        sa_alien(TYPE,COLOR,x,y);
		if (time >= oldTime+1.0) 
		{
		    sa_bolt(0.0);
		    oldTime = time;
		}
	        sa_refresh();
		microsleep(DT*1000000);
	    }
	    microsleep(3000000);
	    sa_teardown();
	}
	return i;
}



