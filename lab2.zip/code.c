/* HAMZA KASHUBECK */

#include "functions.h"
#include "debug.h"
#include <stdio.h>

/* definitions for bit shifting */
#define COLORSHIFT 4
#define TYPESHIFT 12
#define VALUESHIFT 20
#define LAST3BITS 7
#define LAST9BITS 511

/* gets the color of the alien from the code parameter */
int getColor(int code)
{
	int shifted = code >> COLORSHIFT;
	if (DEBUG) 
	{
	    printf("getColor: Isolating last 3 bits after shifting %i on %x returns %i\n",COLORSHIFT,code,shifted&LAST3BITS);
	}
	return shifted&LAST3BITS;
}

/* gets the type of the alien from the given code */
int getType(int code)
{
	int shifted = code >>TYPESHIFT;
	if (DEBUG)
	{
	    printf("getType: Isolating last 3 bits after shifting %i on %x returns %i\n",TYPESHIFT,code,shifted&LAST3BITS);
	}
	return shifted&LAST3BITS;
}

/* gets the point value of the alien from the given code */
int getValue(int code)
{
	int shifted = code >>VALUESHIFT;
	if (DEBUG)
	{
	    printf("getValue: Isolating last 9 bits after shifting %i on %x returns %i\n",VALUESHIFT,code,shifted&LAST9BITS);	
	}
	return shifted&LAST9BITS;
	
}




