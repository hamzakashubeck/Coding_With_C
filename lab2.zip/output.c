/* HAMZA KASHUBECK */

#include "functions.h"
#include "invaders.h"
#include "debug.h"
#include <stdio.h>

/* Print start of simulation message, with parameter of dT */
void printStart(double d)
{
	printf("\nSTART SIMULATION: (dt =%f)\n",d);
}

/* prints message indicating the failure of graphics initialization */
void printFailureToInitialize()
{	
	printf("\nFAILED TO INITIALIZE GRAPHICS!");
}

/* If TEXT, calls outputAlien() once per second. If GRAPHICS, calls outputAlien() every frame.  returns oldTime+1 for storage in the simLoop */
double printWhenTimeIsRight(double time, double oldTime,int hex, double x, double y, double vx, double vy)
{
	if ((time>=(oldTime+1.0)))
	{
	    outputAlien(hex,x,y,vx,vy,time,1);
	    oldTime = oldTime+1.0;
	    if (DEBUG) printf("printWhenTimeIsRight: new second at ET=%lf",time);
	}
	else if (GRAPHICS || DEBUG)
	{
	    outputAlien(hex,x,y,vx,vy,time,0);
	}
	return oldTime;
}

/* outputs alien and base, depending on graphics or text mode. prints bolt if indicated via the parameter "bolt" */
void outputAlien(int hex, double x, double y, double vx, double vy, double elapsed, int bolt)
{
	if (GRAPHICS){
	    sa_clear();
	    sa_base(0.0);
	    sa_alien(getType(hex),getColor(hex),x,y);
	    if (bolt) sa_bolt(0.0);
	    microsleep(DT*1000000);
	    sa_refresh(); }
	if (TEXT || DEBUG)
	{
	    printOneTabularOutput(hex,x,y,vx,vy,elapsed);
	}
}

/* prints one iteration of tabular output from the given inputs */
void printOneTabularOutput(int hex, double x,double y,double vx, double vy,double elapsed)
{	
	printf("\nCode       T C Pts ( __X_____,  __Y_____) ( __VX____,  __VY____) ET=  %f\n", elapsed);
	printf("0x%08x %i %i %3i (%9.5lf, %9.5lf) (%9.5lf, %9.5lf)\n",hex,getType(hex),getColor(hex),getValue(hex),x,y,vx,vy);	
}

/* Print message indicating scanf failed to read a full set of data */
void printScanfFail(int scan)
{
	printf("\nInput terminated: scanf returned %i");
}

/* prints the final statement after the program terminates */
void printEnd(double runTime)
{
	printf("\nTotal runtime is %f seconds.\n",runTime);
}

/* handles printing the output required once the alien hits the boundary */
void printReversal(int code, double x, double y, double vx)
{
	printf("\nAlien 0x%08x at (%.5lf, %.5lf) changes VX to %.5lf\n",code,x,y,vx);
}

/* prints touchdown message */
void printTouchdown(int code, double x)
{
	printf("\nAlien 0x%08x touches down at X=%.5lf!\n",code,x);
}

