/* HAMZA KASHUBECK */

#include "functions.h"
#include "debug.h"
#include "invaders.h"
#include <stdio.h>

/* handles recording the runtime, and kicks off the readLoop() */
int main()
{
	double startTime = now();
	if (GRAPHICS && sa_initialize()==0) printFailureToInitialize();
	readLoop();
	terminate(startTime);
	return 0;
}

/* reads alien from the input stream and hands it to simLoop() if it's valid */
void readLoop()
{
	while(1)
	{
	    double x,y,vx,vy;
	    int code, numValues = scanf("%x %lf %lf %lf %lf", &code, &x, &y, &vx, &vy);
	    if (numValues != 5)	{
		printScanfFail(numValues);
		return; }
	    else { simLoop(code,x,y,vx,vy); }
	}
}

/* handles the core simulation loop for one alien */
void simLoop(int code,double x,double y, double vx, double vy)
{
	double time = 0.0,last=0.0;	
	startSim(code,x,y,vx,vy,time);
	while(y>0)
	{
	    x = updateVar(x,vx);
	    y = updateVar(y,vy);
	    vx = negateVX(code,x,y,vx,vy,time);
	    time = time + DT;
	    last = printWhenTimeIsRight(time,last,code,x,y,vx,vy);
	}
	printTouchdown(code,x);
	outputAlien(code,x,y,vx,vy,time,0);
}

/* Prints starting message and alien output at t=0.0 */
void startSim(int hex,double x,double y,double vx,double vy,double time)
{	
	printStart(DT);
	outputAlien(hex,x,y,vx,vy,time,1);
}

/* handles final print statements & graphics teardown */
void terminate(double timestamp)
{
	if (GRAPHICS) sa_teardown();
	printEnd(now()-timestamp);
}


