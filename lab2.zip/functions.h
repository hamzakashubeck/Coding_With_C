/* Hamza Kashubeck */

#define DT 0.03125

/* from lab2.c */
void readLoop();
void simLoop(int code,double x,double y, double vx, double vy);
void startSim(int hex,double x,double y,double vx,double vy,double time);
void terminate(double timestamp);


/* from output.c */
void printStart(double d);
void printScanfFail(int scan);
void outputAlien(int hex, double x, double y, double vx, double vy, double elapsed,int bolt);
void printEnd(double runTime);
void printReversal(int code, double x, double y, double vx);
void printTouchdown(int code, double x);
void printFailureToInitialize();
void printOneTabularOutput(int hex,double x,double y, double vx, double vy, double time);
double printWhenTimeIsRight(double time, double oldTime,int hex, double x, double y, double vx, double vy);

/* from code.c */
int getColor(int code);
int getValue(int code);
int getType(int code);

/* from motion.c */
double updateVar(double oldPos, double oldVel);
double negateVX(int code, double x, double y, double vx,double vy, double startTime);







