/* HAMZA KASHUBECK */

#include "functions.h"

/* updates the parameter variable once, depending on framerate */
double updateVar(double oldPos, double oldVelocity)
{
	return oldPos + (oldVelocity*DT);
}

/* negates vx and prints required text if the alien is heading out of bounds */
double negateVX(int code, double x, double y, double vx,double vy, double startTime)
{
	double newVX = vx;
	if ((x >= 39.0 && vx > 0.0) || (x <= -39.0 && vx < 0.0))
	{
	    vx =  vx*(-1.0);
	    printReversal(code,x,y,vx);
	}
	return vx;
}

