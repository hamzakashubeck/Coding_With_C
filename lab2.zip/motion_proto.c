/* Hamza Kashubeck */
/* Adding motion to the aliens from the last prototype draw_proto */
#include "invaders.h"
#include <stdio.h>

#define DT 0.03125
#define TYPE 1
#define COLOR 1

/*sets up graphics with alien & base, then sets the alien in motion. teardown happens a few seconds after the alien touches down */
int main()
{
	int i =0;
	double x = 7.0, y = 12.0;
	double vx = 10.0, vy = -2.0;
	if (i=sa_initialize())
	{
	    sa_clear();
	    sa_base(0.0);
	    sa_refresh();

	    while (y>0)
	    {
	        x = x + (vx*DT);
	        y = y + (vy*DT);
	        if ((x >= 39.0 && vx > 0.0) || (x <= -39.0 && vx < 0.0))
	        {
	            vx = vx*-1.0;
	        }
	        sa_clear();
	        sa_base(0.0);
	        sa_alien(TYPE,COLOR,x,y);
	        sa_refresh();
		microsleep(DT*1000000);
	    }
	    microsleep(3000000);
	    sa_teardown();
	}
	return i;
}



